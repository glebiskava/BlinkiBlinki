public class Encoder {
    public static String encode(LedRequest request){
        return request.encode();
    }
}
