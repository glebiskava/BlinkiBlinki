public abstract class LedRequest implements EncodeDecode{
    
}
