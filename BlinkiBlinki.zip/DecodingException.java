public class DecodingException extends Exception {
    public DecodingException(){
        super();
    }

    public DecodingException(String m){
        super(m);
    }
}
